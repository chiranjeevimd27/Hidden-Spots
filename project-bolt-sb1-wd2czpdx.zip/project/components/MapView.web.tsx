import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const MockMapView = ({ children, ...props }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Map functionality is not available on web.</Text>
      <Text style={styles.text}>Please use the mobile app for full map features.</Text>
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f0f0f0',
    minHeight: 300,
    borderRadius: 8,
    margin: 16,
  },
  text: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginVertical: 5,
    fontFamily: 'Inter-Regular',
  }
});

export const Marker = ({ children }) => children;
export const PROVIDER_GOOGLE = 'google';
export default MockMapView;