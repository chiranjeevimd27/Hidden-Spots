import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  Pressable,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import {
  ArrowLeft,
  Star,
  MapPin,
  Users,
  Shield,
  Sparkles,
  Heart,
  MessageCircle,
  Share2,
  Camera,
} from 'lucide-react-native';
import { hiddenSpots, getCategoryColor, HiddenSpot, Experience } from '@/data/spots';

export default function SpotDetailsScreen() {
  const { id } = useLocalSearchParams();
  const spot = hiddenSpots.find(s => s.id === id);
  const [selectedPhoto, setSelectedPhoto] = useState(0);
  const [newExperience, setNewExperience] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);

  if (!spot) {
    return (
      <SafeAreaView style={styles.container}>
        <Text>Spot not found</Text>
      </SafeAreaView>
    );
  }

  const handleAddExperience = () => {
    if (newExperience.trim()) {
      Alert.alert('Experience Added', 'Your experience has been shared with the community!');
      setNewExperience('');
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return '#10B981';
    if (rating >= 3.5) return '#F59E0B';
    return '#EF4444';
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} size={16} color="#F59E0B" fill="#F59E0B" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <Star key="half" size={16} color="#F59E0B" fill="#F59E0B" />
      );
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(
        <Star key={`empty-${i}`} size={16} color="#D1D5DB" />
      );
    }

    return stars;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <ArrowLeft size={24} color="#111827" />
        </Pressable>
        <View style={styles.headerActions}>
          <Pressable style={styles.actionButton}>
            <Share2 size={20} color="#6B7280" />
          </Pressable>
          <Pressable style={styles.actionButton}>
            <Heart size={20} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Photo Gallery */}
        <View style={styles.photoGallery}>
          <Image source={{ uri: spot.photos[selectedPhoto] }} style={styles.mainPhoto} />
          <View style={styles.photoThumbnails}>
            {spot.photos.map((photo, index) => (
              <Pressable
                key={index}
                onPress={() => setSelectedPhoto(index)}
                style={[
                  styles.thumbnail,
                  selectedPhoto === index && styles.thumbnailSelected
                ]}
              >
                <Image source={{ uri: photo }} style={styles.thumbnailImage} />
              </Pressable>
            ))}
          </View>
        </View>

        {/* Spot Info */}
        <View style={styles.spotInfo}>
          <View style={styles.categoryBadge}>
            <View
              style={[
                styles.categoryDot,
                { backgroundColor: getCategoryColor(spot.category) }
              ]}
            />
            <Text style={styles.categoryText}>
              {spot.category.charAt(0).toUpperCase() + spot.category.slice(1)}
            </Text>
          </View>

          <Text style={styles.spotName}>{spot.name}</Text>
          <Text style={styles.spotDescription}>{spot.description}</Text>

          {/* Location */}
          <View style={styles.locationContainer}>
            <MapPin size={16} color="#6B7280" />
            <Text style={styles.locationText}>Gwalior, Madhya Pradesh</Text>
          </View>

          {/* Ratings */}
          <View style={styles.ratingsContainer}>
            <Text style={styles.sectionTitle}>Community Ratings</Text>
            <View style={styles.ratingGrid}>
              <View style={styles.ratingItem}>
                <Sparkles size={20} color="#F59E0B" />
                <Text style={styles.ratingLabel}>Uniqueness</Text>
                <View style={styles.ratingValue}>
                  <Text style={[styles.ratingNumber, { color: getRatingColor(spot.ratings.uniqueness) }]}>
                    {spot.ratings.uniqueness}
                  </Text>
                  <View style={styles.stars}>
                    {renderStars(spot.ratings.uniqueness)}
                  </View>
                </View>
              </View>

              <View style={styles.ratingItem}>
                <Heart size={20} color="#EC4899" />
                <Text style={styles.ratingLabel}>Vibe</Text>
                <View style={styles.ratingValue}>
                  <Text style={[styles.ratingNumber, { color: getRatingColor(spot.ratings.vibe) }]}>
                    {spot.ratings.vibe}
                  </Text>
                  <View style={styles.stars}>
                    {renderStars(spot.ratings.vibe)}
                  </View>
                </View>
              </View>

              <View style={styles.ratingItem}>
                <Shield size={20} color="#10B981" />
                <Text style={styles.ratingLabel}>Safety</Text>
                <View style={styles.ratingValue}>
                  <Text style={[styles.ratingNumber, { color: getRatingColor(spot.ratings.safety) }]}>
                    {spot.ratings.safety}
                  </Text>
                  <View style={styles.stars}>
                    {renderStars(spot.ratings.safety)}
                  </View>
                </View>
              </View>

              <View style={styles.ratingItem}>
                <Users size={20} color="#6366F1" />
                <Text style={styles.ratingLabel}>Crowd Level</Text>
                <View style={styles.ratingValue}>
                  <Text style={[styles.ratingNumber, { color: getRatingColor(5 - spot.ratings.crowdLevel) }]}>
                    {spot.ratings.crowdLevel}
                  </Text>
                  <Text style={styles.crowdText}>
                    {spot.ratings.crowdLevel < 2 ? 'Peaceful' : 
                     spot.ratings.crowdLevel < 3.5 ? 'Moderate' : 'Busy'}
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* Story */}
          <View style={styles.storyContainer}>
            <Text style={styles.sectionTitle}>The Story</Text>
            <Text style={styles.storyText}>{spot.story}</Text>
            <Text style={styles.authorText}>— Shared by {spot.submittedBy}</Text>
          </View>

          {/* Tips */}
          <View style={styles.tipsContainer}>
            <Text style={styles.sectionTitle}>Local Tips</Text>
            {spot.tips.map((tip, index) => (
              <View key={index} style={styles.tipItem}>
                <View style={styles.tipBullet} />
                <Text style={styles.tipText}>{tip}</Text>
              </View>
            ))}
          </View>

          {/* Community Experiences */}
          <View style={styles.experiencesContainer}>
            <Text style={styles.sectionTitle}>Community Experiences</Text>
            {spot.experiences.map((experience) => (
              <View key={experience.id} style={styles.experienceItem}>
                <View style={styles.experienceHeader}>
                  <Text style={styles.experienceAuthor}>
                    {experience.isAnonymous ? 'Anonymous' : experience.author}
                  </Text>
                  <Text style={styles.experienceDate}>
                    {new Date(experience.createdAt).toLocaleDateString()}
                  </Text>
                </View>
                <Text style={styles.experienceText}>{experience.text}</Text>
                <View style={styles.experienceFooter}>
                  <Pressable style={styles.likeButton}>
                    <Heart size={14} color="#EC4899" />
                    <Text style={styles.likeCount}>{experience.likes}</Text>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>

          {/* Add Experience */}
          <View style={styles.addExperienceContainer}>
            <Text style={styles.sectionTitle}>Share Your Experience</Text>
            <TextInput
              style={styles.experienceInput}
              placeholder="Tell the community about your experience at this spot..."
              value={newExperience}
              onChangeText={setNewExperience}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
            <View style={styles.experienceOptions}>
              <Pressable
                style={styles.anonymousToggle}
                onPress={() => setIsAnonymous(!isAnonymous)}
              >
                <View style={[
                  styles.checkbox,
                  isAnonymous && styles.checkboxChecked
                ]}>
                  {isAnonymous && <Text style={styles.checkmark}>✓</Text>}
                </View>
                <Text style={styles.anonymousText}>Post anonymously</Text>
              </Pressable>
              <Pressable style={styles.shareButton} onPress={handleAddExperience}>
                <MessageCircle size={16} color="white" />
                <Text style={styles.shareButtonText}>Share</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    padding: 8,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    padding: 8,
  },
  content: {
    flex: 1,
  },
  photoGallery: {
    height: 300,
  },
  mainPhoto: {
    width: '100%',
    height: 250,
    resizeMode: 'cover',
  },
  photoThumbnails: {
    flexDirection: 'row',
    padding: 16,
    gap: 8,
  },
  thumbnail: {
    width: 60,
    height: 40,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  thumbnailSelected: {
    borderColor: '#14B8A6',
  },
  thumbnailImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  spotInfo: {
    padding: 20,
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  spotName: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 8,
  },
  spotDescription: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
    marginBottom: 16,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  locationText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 6,
  },
  ratingsContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 16,
  },
  ratingGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  ratingItem: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  ratingLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 8,
    marginBottom: 4,
  },
  ratingValue: {
    alignItems: 'center',
  },
  ratingNumber: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  stars: {
    flexDirection: 'row',
    gap: 2,
  },
  crowdText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 4,
  },
  storyContainer: {
    marginBottom: 24,
  },
  storyText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 24,
    marginBottom: 12,
  },
  authorText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    fontStyle: 'italic',
  },
  tipsContainer: {
    marginBottom: 24,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  tipBullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#14B8A6',
    marginTop: 8,
    marginRight: 12,
  },
  tipText: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 20,
  },
  experiencesContainer: {
    marginBottom: 24,
  },
  experienceItem: {
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  experienceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  experienceAuthor: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
  experienceDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  experienceText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 20,
    marginBottom: 12,
  },
  experienceFooter: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  likeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  likeCount: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#EC4899',
  },
  addExperienceContainer: {
    marginBottom: 24,
  },
  experienceInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 16,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#111827',
    minHeight: 100,
    marginBottom: 16,
  },
  experienceOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  anonymousToggle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#D1D5DB',
    borderRadius: 4,
    marginRight: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#14B8A6',
    borderColor: '#14B8A6',
  },
  checkmark: {
    color: 'white',
    fontSize: 12,
    fontFamily: 'Inter-Bold',
  },
  anonymousText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#14B8A6',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  shareButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});