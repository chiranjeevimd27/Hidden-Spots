import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  User,
  MapPin,
  Star,
  Heart,
  Camera,
  Settings,
  Share2,
  Award,
  Calendar,
  Compass,
} from 'lucide-react-native';
import { hiddenSpots } from '@/data/spots';

export default function ProfileScreen() {
  const userStats = {
    spotsDiscovered: hiddenSpots.length,
    spotsShared: 2,
    totalLikes: 35,
    reviewsWritten: 8,
    joinDate: 'January 2024',
  };

  const achievements = [
    { id: 1, title: 'Explorer', description: 'Discovered 5+ spots', icon: 'compass', earned: true },
    { id: 2, title: 'Storyteller', description: 'Shared 3+ experiences', icon: 'star', earned: true },
    { id: 3, title: 'Photographer', description: 'Uploaded 10+ photos', icon: 'camera', earned: false },
    { id: 4, title: 'Local Guide', description: 'Helped 50+ users', icon: 'map-pin', earned: false },
  ];

  const recentActivity = [
    { id: 1, type: 'visit', spot: 'Sunset Point at Gwalior Fort', date: '2 days ago' },
    { id: 2, type: 'review', spot: 'Hidden Garden Behind Jai Vilas Palace', date: '1 week ago' },
    { id: 3, type: 'photo', spot: 'Artist Café at Phool Bagh', date: '2 weeks ago' },
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'visit':
        return <MapPin size={16} color="#14B8A6" />;
      case 'review':
        return <Star size={16} color="#F59E0B" />;
      case 'photo':
        return <Camera size={16} color="#EC4899" />;
      default:
        return <Compass size={16} color="#6B7280" />;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
        <Pressable style={styles.settingsButton}>
          <Settings size={24} color="#6B7280" />
        </Pressable>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Profile Info */}
        <View style={styles.profileSection}>
          <View style={styles.profileHeader}>
            <View style={styles.avatarContainer}>
              <User size={32} color="#FFFFFF" />
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>Arjun Mehta</Text>
              <Text style={styles.profileLocation}>Gwalior, Madhya Pradesh</Text>
              <Text style={styles.joinDate}>Joined {userStats.joinDate}</Text>
            </View>
            <Pressable style={styles.shareButton}>
              <Share2 size={20} color="#6B7280" />
            </Pressable>
          </View>

          <Text style={styles.profileBio}>
            Explorer of hidden gems and local culture enthusiast. Love discovering peaceful spots 
            and sharing stories that connect people to places.
          </Text>
        </View>

        {/* Stats */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Your Hidden Spots Journey</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Compass size={24} color="#14B8A6" />
              <Text style={styles.statNumber}>{userStats.spotsDiscovered}</Text>
              <Text style={styles.statLabel}>Spots Discovered</Text>
            </View>
            <View style={styles.statCard}>
              <MapPin size={24} color="#F59E0B" />
              <Text style={styles.statNumber}>{userStats.spotsShared}</Text>
              <Text style={styles.statLabel}>Spots Shared</Text>
            </View>
            <View style={styles.statCard}>
              <Heart size={24} color="#EC4899" />
              <Text style={styles.statNumber}>{userStats.totalLikes}</Text>
              <Text style={styles.statLabel}>Likes Received</Text>
            </View>
            <View style={styles.statCard}>
              <Star size={24} color="#8B5CF6" />
              <Text style={styles.statNumber}>{userStats.reviewsWritten}</Text>
              <Text style={styles.statLabel}>Reviews Written</Text>
            </View>
          </View>
        </View>

        {/* Achievements */}
        <View style={styles.achievementsSection}>
          <Text style={styles.sectionTitle}>Achievements</Text>
          <View style={styles.achievementsGrid}>
            {achievements.map((achievement) => (
              <View
                key={achievement.id}
                style={[
                  styles.achievementCard,
                  !achievement.earned && styles.achievementCardLocked
                ]}
              >
                <View style={[
                  styles.achievementIcon,
                  { backgroundColor: achievement.earned ? '#14B8A6' : '#D1D5DB' }
                ]}>
                  <Award size={20} color={achievement.earned ? '#FFFFFF' : '#9CA3AF'} />
                </View>
                <Text style={[
                  styles.achievementTitle,
                  !achievement.earned && styles.achievementTitleLocked
                ]}>
                  {achievement.title}
                </Text>
                <Text style={[
                  styles.achievementDescription,
                  !achievement.earned && styles.achievementDescriptionLocked
                ]}>
                  {achievement.description}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent Activity */}
        <View style={styles.activitySection}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <View style={styles.activityList}>
            {recentActivity.map((activity) => (
              <View key={activity.id} style={styles.activityItem}>
                <View style={styles.activityIcon}>
                  {getActivityIcon(activity.type)}
                </View>
                <View style={styles.activityContent}>
                  <Text style={styles.activityText}>
                    {activity.type === 'visit' && 'Visited '}
                    {activity.type === 'review' && 'Reviewed '}
                    {activity.type === 'photo' && 'Added photos to '}
                    <Text style={styles.spotName}>{activity.spot}</Text>
                  </Text>
                  <Text style={styles.activityDate}>{activity.date}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Favorites */}
        <View style={styles.favoritesSection}>
          <Text style={styles.sectionTitle}>Your Favorite Spots</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.favoritesList}>
              {hiddenSpots.slice(0, 3).map((spot) => (
                <View key={spot.id} style={styles.favoriteCard}>
                  <Image source={{ uri: spot.photos[0] }} style={styles.favoriteImage} />
                  <View style={styles.favoriteOverlay}>
                    <Text style={styles.favoriteName} numberOfLines={1}>
                      {spot.name}
                    </Text>
                    <View style={styles.favoriteRating}>
                      <Star size={12} color="#F59E0B" fill="#F59E0B" />
                      <Text style={styles.favoriteRatingText}>
                        {((spot.ratings.uniqueness + spot.ratings.vibe + spot.ratings.safety) / 3).toFixed(1)}
                      </Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </ScrollView>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#111827',
  },
  settingsButton: {
    padding: 8,
  },
  content: {
    flex: 1,
  },
  profileSection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 8,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 2,
  },
  profileLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  joinDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  shareButton: {
    padding: 8,
  },
  profileBio: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 20,
  },
  statsSection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  achievementsSection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 8,
  },
  achievementsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  achievementCard: {
    flex: 1,
    minWidth: '45%',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#F0FDFA',
    alignItems: 'center',
  },
  achievementCardLocked: {
    backgroundColor: '#F9FAFB',
  },
  achievementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  achievementTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  achievementTitleLocked: {
    color: '#9CA3AF',
  },
  achievementDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
  achievementDescriptionLocked: {
    color: '#D1D5DB',
  },
  activitySection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 8,
  },
  activityList: {
    gap: 12,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  activityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    marginBottom: 2,
  },
  spotName: {
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
  activityDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  favoritesSection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 20,
  },
  favoritesList: {
    flexDirection: 'row',
    gap: 12,
    paddingRight: 20,
  },
  favoriteCard: {
    width: 120,
    height: 120,
    borderRadius: 12,
    overflow: 'hidden',
  },
  favoriteImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  favoriteOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 8,
  },
  favoriteName: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  favoriteRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  favoriteRatingText: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
  },
});