import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Image,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Filter, Star, MapPin, Users } from 'lucide-react-native';
import { hiddenSpots, getCategoryColor } from '@/data/spots';
import { router } from 'expo-router';

export default function DiscoverScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);

  const filteredSpots = hiddenSpots.filter(spot => {
    const matchesSearch = spot.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         spot.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = !selectedFilter || spot.category === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  const getAverageRating = (ratings: any) => {
    const sum = ratings.uniqueness + ratings.vibe + ratings.safety + (5 - ratings.crowdLevel);
    return (sum / 4).toFixed(1);
  };

  const handleSpotPress = (spotId: string) => {
    router.push(`/spot-details?id=${spotId}`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Discover Hidden Spots</Text>
        <Text style={styles.subtitle}>Find your next adventure in Gwalior</Text>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color="#9CA3AF" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search for spots, vibes, or experiences..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <Pressable style={styles.filterButton}>
          <Filter size={20} color="#6B7280" />
        </Pressable>
      </View>

      {/* Filter Tags */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.filterTags}
        contentContainerStyle={styles.filterTagsContent}
      >
        <Pressable
          style={[
            styles.filterTag,
            selectedFilter === null && styles.filterTagActive
          ]}
          onPress={() => setSelectedFilter(null)}
        >
          <Text style={[
            styles.filterTagText,
            selectedFilter === null && styles.filterTagTextActive
          ]}>
            All Spots
          </Text>
        </Pressable>
        {['romantic', 'serene', 'creative', 'adventure'].map((category) => (
          <Pressable
            key={category}
            style={[
              styles.filterTag,
              selectedFilter === category && styles.filterTagActive
            ]}
            onPress={() => setSelectedFilter(
              selectedFilter === category ? null : category
            )}
          >
            <Text style={[
              styles.filterTagText,
              selectedFilter === category && styles.filterTagTextActive
            ]}>
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Spots List */}
      <ScrollView style={styles.spotsList} showsVerticalScrollIndicator={false}>
        <View style={styles.spotsGrid}>
          {filteredSpots.map((spot) => (
            <Pressable
              key={spot.id}
              style={styles.spotCard}
              onPress={() => handleSpotPress(spot.id)}
            >
              <Image source={{ uri: spot.photos[0] }} style={styles.spotImage} />
              
              <View style={styles.spotOverlay}>
                <View style={[
                  styles.categoryBadge,
                  { backgroundColor: getCategoryColor(spot.category) }
                ]}>
                  <Text style={styles.categoryBadgeText}>
                    {spot.category.charAt(0).toUpperCase() + spot.category.slice(1)}
                  </Text>
                </View>
              </View>

              <View style={styles.spotInfo}>
                <Text style={styles.spotName} numberOfLines={1}>{spot.name}</Text>
                <Text style={styles.spotDescription} numberOfLines={2}>
                  {spot.description}
                </Text>

                <View style={styles.spotMeta}>
                  <View style={styles.rating}>
                    <Star size={14} color="#F59E0B" fill="#F59E0B" />
                    <Text style={styles.ratingText}>
                      {getAverageRating(spot.ratings)}
                    </Text>
                  </View>

                  <View style={styles.location}>
                    <MapPin size={12} color="#9CA3AF" />
                    <Text style={styles.locationText}>Gwalior</Text>
                  </View>
                </View>

                <View style={styles.spotStats}>
                  <View style={styles.stat}>
                    <Users size={12} color="#6B7280" />
                    <Text style={styles.statText}>
                      {spot.ratings.crowdLevel < 2 ? 'Peaceful' : 
                       spot.ratings.crowdLevel < 3.5 ? 'Moderate' : 'Busy'}
                    </Text>
                  </View>
                  <Text style={styles.experienceCount}>
                    {spot.experiences.length} experience{spot.experiences.length !== 1 ? 's' : ''}
                  </Text>
                </View>
              </View>
            </Pressable>
          ))}
        </View>

        {filteredSpots.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateTitle}>No spots found</Text>
            <Text style={styles.emptyStateText}>
              Try adjusting your search or filters to discover more hidden gems.
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  searchContainer: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#111827',
  },
  filterButton: {
    padding: 12,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterTags: {
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  filterTagsContent: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  filterTag: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  filterTagActive: {
    backgroundColor: '#14B8A6',
    borderColor: '#14B8A6',
  },
  filterTagText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  filterTagTextActive: {
    color: '#FFFFFF',
  },
  spotsList: {
    flex: 1,
  },
  spotsGrid: {
    padding: 16,
    gap: 16,
  },
  spotCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  spotImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  spotOverlay: {
    position: 'absolute',
    top: 12,
    left: 12,
  },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryBadgeText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  spotInfo: {
    padding: 16,
  },
  spotName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  spotDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 12,
  },
  spotMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#9CA3AF',
  },
  spotStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  stat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  experienceCount: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyStateTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
  },
});