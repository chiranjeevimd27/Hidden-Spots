import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Pressable,
  Image,
  Alert,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Camera, MapPin, Star, Upload, X } from 'lucide-react-native';
import * as Location from 'expo-location';
import { CameraView, useCameraPermissions } from 'expo-camera';

export default function AddSpotScreen() {
  const [spotName, setSpotName] = useState('');
  const [spotDescription, setSpotDescription] = useState('');
  const [spotStory, setSpotStory] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [photos, setPhotos] = useState<string[]>([]);
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [permission, requestPermission] = useCameraPermissions();

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    if (Platform.OS === 'web') {
      // For web, we'll use the default Gwalior location
      setLocation({
        coords: {
          latitude: 26.2124,
          longitude: 78.1772,
          altitude: null,
          accuracy: null,
          altitudeAccuracy: null,
          heading: null,
          speed: null,
        },
        timestamp: Date.now(),
      });
      return;
    }

    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission denied', 'Location permission is required to add a spot');
      return;
    }

    let currentLocation = await Location.getCurrentPositionAsync({});
    setLocation(currentLocation);
  };

  const categories = [
    { key: 'romantic', label: 'Romantic', color: '#EC4899', description: 'Perfect for dates and intimate moments' },
    { key: 'serene', label: 'Serene', color: '#10B981', description: 'Peaceful and calming atmosphere' },
    { key: 'creative', label: 'Creative', color: '#F59E0B', description: 'Inspiring for artists and thinkers' },
    { key: 'adventure', label: 'Adventure', color: '#EF4444', description: 'Exciting and thrilling experiences' },
  ];

  const handleTakePhoto = async () => {
    if (!permission?.granted) {
      const permissionResult = await requestPermission();
      if (!permissionResult.granted) {
        Alert.alert('Permission needed', 'Camera permission is required to take photos');
        return;
      }
    }
    setShowCamera(true);
  };

  const handleAddPhoto = () => {
    // Simulate adding a photo
    const mockPhoto = 'https://images.pexels.com/photos/1603650/pexels-photo-1603650.jpeg';
    setPhotos([...photos, mockPhoto]);
    Alert.alert('Photo Added', 'Your photo has been added to the gallery!');
  };

  const removePhoto = (index: number) => {
    const newPhotos = photos.filter((_, i) => i !== index);
    setPhotos(newPhotos);
  };

  const handleSubmit = () => {
    if (!spotName.trim()) {
      Alert.alert('Missing Information', 'Please enter a spot name');
      return;
    }
    if (!spotDescription.trim()) {
      Alert.alert('Missing Information', 'Please enter a description');
      return;
    }
    if (!selectedCategory) {
      Alert.alert('Missing Information', 'Please select a category');
      return;
    }
    if (photos.length === 0) {
      Alert.alert('Missing Information', 'Please add at least one photo');
      return;
    }

    Alert.alert(
      'Spot Submitted!',
      'Thank you for contributing to the Hidden Spots community! Your spot will be reviewed and added to the map.',
      [{ text: 'Great!', onPress: resetForm }]
    );
  };

  const resetForm = () => {
    setSpotName('');
    setSpotDescription('');
    setSpotStory('');
    setSelectedCategory(null);
    setPhotos([]);
  };

  if (showCamera && Platform.OS !== 'web') {
    return (
      <SafeAreaView style={styles.container}>
        <CameraView style={styles.camera}>
          <View style={styles.cameraControls}>
            <Pressable
              style={styles.cameraButton}
              onPress={() => setShowCamera(false)}
            >
              <X size={24} color="white" />
            </Pressable>
            <Pressable
              style={styles.captureButton}
              onPress={handleAddPhoto}
            >
              <View style={styles.captureButtonInner} />
            </Pressable>
          </View>
        </CameraView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Add Hidden Spot</Text>
        <Text style={styles.subtitle}>Share your secret discovery with the community</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Location Info */}
        <View style={styles.locationInfo}>
          <View style={styles.locationHeader}>
            <MapPin size={20} color="#14B8A6" />
            <Text style={styles.locationTitle}>Current Location</Text>
          </View>
          <Text style={styles.locationText}>
            {location ? 'Gwalior, Madhya Pradesh' : 'Getting your location...'}
          </Text>
        </View>

        {/* Basic Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Spot Information</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Spot Name *</Text>
            <TextInput
              style={styles.textInput}
              placeholder="Give your spot a memorable name"
              value={spotName}
              onChangeText={setSpotName}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Description *</Text>
            <TextInput
              style={[styles.textInput, styles.textArea]}
              placeholder="Describe what makes this spot special"
              value={spotDescription}
              onChangeText={setSpotDescription}
              multiline
              numberOfLines={3}
              textAlignVertical="top"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Your Story</Text>
            <TextInput
              style={[styles.textInput, styles.textArea]}
              placeholder="Share how you discovered this place and what it means to you"
              value={spotStory}
              onChangeText={setSpotStory}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>
        </View>

        {/* Category Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Spot Category *</Text>
          <Text style={styles.sectionSubtitle}>Choose the vibe that best describes this spot</Text>
          
          <View style={styles.categoryGrid}>
            {categories.map((category) => (
              <Pressable
                key={category.key}
                style={[
                  styles.categoryCard,
                  selectedCategory === category.key && styles.categoryCardSelected
                ]}
                onPress={() => setSelectedCategory(category.key)}
              >
                <View
                  style={[
                    styles.categoryIcon,
                    { backgroundColor: category.color }
                  ]}
                />
                <Text style={[
                  styles.categoryLabel,
                  selectedCategory === category.key && styles.categoryLabelSelected
                ]}>
                  {category.label}
                </Text>
                <Text style={[
                  styles.categoryDescription,
                  selectedCategory === category.key && styles.categoryDescriptionSelected
                ]}>
                  {category.description}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Photo Upload */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Photos *</Text>
          <Text style={styles.sectionSubtitle}>Add photos to showcase your spot</Text>

          <View style={styles.photoContainer}>
            {photos.map((photo, index) => (
              <View key={index} style={styles.photoItem}>
                <Image source={{ uri: photo }} style={styles.photoImage} />
                <Pressable
                  style={styles.removePhotoButton}
                  onPress={() => removePhoto(index)}
                >
                  <X size={16} color="white" />
                </Pressable>
              </View>
            ))}
            
            <Pressable style={styles.addPhotoButton} onPress={handleTakePhoto}>
              <Camera size={24} color="#6B7280" />
              <Text style={styles.addPhotoText}>Take Photo</Text>
            </Pressable>

            <Pressable style={styles.addPhotoButton} onPress={handleAddPhoto}>
              <Upload size={24} color="#6B7280" />
              <Text style={styles.addPhotoText}>Add from Gallery</Text>
            </Pressable>
          </View>
        </View>

        {/* Submit Button */}
        <View style={styles.submitContainer}>
          <Pressable style={styles.submitButton} onPress={handleSubmit}>
            <Text style={styles.submitButtonText}>Share Hidden Spot</Text>
          </Pressable>
          <Text style={styles.submitNote}>
            Your spot will be reviewed by our community moderators before being added to the map.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  content: {
    flex: 1,
  },
  locationInfo: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    marginBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  locationTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginLeft: 8,
  },
  locationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  section: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#111827',
    backgroundColor: '#FFFFFF',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryCard: {
    flex: 1,
    minWidth: '45%',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
  },
  categoryCardSelected: {
    borderColor: '#14B8A6',
    backgroundColor: '#F0FDFA',
  },
  categoryIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginBottom: 12,
  },
  categoryLabel: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  categoryLabelSelected: {
    color: '#14B8A6',
  },
  categoryDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 16,
  },
  categoryDescriptionSelected: {
    color: '#0D9488',
  },
  photoContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  photoItem: {
    position: 'relative',
    width: 100,
    height: 100,
  },
  photoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    resizeMode: 'cover',
  },
  removePhotoButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#EF4444',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addPhotoButton: {
    width: 100,
    height: 100,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#D1D5DB',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F9FAFB',
  },
  addPhotoText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 4,
    textAlign: 'center',
  },
  submitContainer: {
    padding: 20,
    backgroundColor: '#FFFFFF',
  },
  submitButton: {
    backgroundColor: '#14B8A6',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  submitButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  submitNote: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 16,
  },
  camera: {
    flex: 1,
  },
  cameraControls: {
    flex: 1,
    backgroundColor: 'transparent',
    flexDirection: 'row',
    margin: 20,
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  cameraButton: {
    padding: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 8,
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  captureButtonInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#FFFFFF',
  },
});