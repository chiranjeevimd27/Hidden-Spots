import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, Pressable, Alert, Platform } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, Filter, Search } from 'lucide-react-native';
import { hiddenSpots, getCategoryColor, HiddenSpot } from '@/data/spots';
import { router } from 'expo-router';

const GWALIOR_REGION = {
  latitude: 26.2124,
  longitude: 78.1772,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export default function MapScreen() {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [filteredSpots, setFilteredSpots] = useState(hiddenSpots);

  useEffect(() => {
    getCurrentLocation();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      setFilteredSpots(hiddenSpots.filter(spot => spot.category === selectedCategory));
    } else {
      setFilteredSpots(hiddenSpots);
    }
  }, [selectedCategory]);

  const getCurrentLocation = async () => {
    if (Platform.OS === 'web') {
      // For web, we'll use the default Gwalior location
      return;
    }

    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission denied', 'Location permission is required to show your current position');
      return;
    }

    let currentLocation = await Location.getCurrentPositionAsync({});
    setLocation(currentLocation);
  };

  const handleMarkerPress = (spot: HiddenSpot) => {
    router.push(`/spot-details?id=${spot.id}`);
  };

  const categories = [
    { key: 'romantic', label: 'Romantic', color: '#EC4899' },
    { key: 'serene', label: 'Serene', color: '#10B981' },
    { key: 'creative', label: 'Creative', color: '#F59E0B' },
    { key: 'adventure', label: 'Adventure', color: '#EF4444' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Hidden Spots</Text>
        <Text style={styles.subtitle}>Discover Gwalior's Secret Gems</Text>
      </View>

      <View style={styles.filterContainer}>
        <Pressable
          style={[
            styles.filterButton,
            selectedCategory === null && styles.filterButtonActive
          ]}
          onPress={() => setSelectedCategory(null)}
        >
          <Text style={[
            styles.filterButtonText,
            selectedCategory === null && styles.filterButtonTextActive
          ]}>
            All
          </Text>
        </Pressable>
        {categories.map((category) => (
          <Pressable
            key={category.key}
            style={[
              styles.filterButton,
              selectedCategory === category.key && styles.filterButtonActive
            ]}
            onPress={() => setSelectedCategory(
              selectedCategory === category.key ? null : category.key
            )}
          >
            <Text style={[
              styles.filterButtonText,
              selectedCategory === category.key && styles.filterButtonTextActive
            ]}>
              {category.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <MapView
        style={styles.map}
        provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
        initialRegion={GWALIOR_REGION}
        showsUserLocation={Platform.OS !== 'web'}
        showsMyLocationButton={Platform.OS !== 'web'}
      >
        {filteredSpots.map((spot) => (
          <Marker
            key={spot.id}
            coordinate={{
              latitude: spot.latitude,
              longitude: spot.longitude,
            }}
            title={spot.name}
            description={spot.description}
            pinColor={getCategoryColor(spot.category)}
            onPress={() => handleMarkerPress(spot)}
          >
            <View style={[
              styles.customMarker,
              { backgroundColor: getCategoryColor(spot.category) }
            ]}>
              <MapPin size={20} color="white" />
            </View>
          </Marker>
        ))}
      </MapView>

      <View style={styles.statsContainer}>
        <Text style={styles.statsText}>
          Showing {filteredSpots.length} hidden spots in Gwalior
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  filterContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#FFFFFF',
    gap: 8,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  filterButtonActive: {
    backgroundColor: '#14B8A6',
    borderColor: '#14B8A6',
  },
  filterButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  filterButtonTextActive: {
    color: '#FFFFFF',
  },
  map: {
    flex: 1,
  },
  customMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  statsContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  statsText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
});