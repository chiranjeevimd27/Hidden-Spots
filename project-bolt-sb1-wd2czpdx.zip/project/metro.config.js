const { getDefaultConfig } = require('@expo/metro-config');
const path = require('path');

const config = getDefaultConfig(__dirname);

config.resolver.resolveRequest = (context, moduleName, platform) => {
  // Redirect all react-native-maps imports to our web mock when on web platform
  if (platform === 'web' && (moduleName === 'react-native-maps' || moduleName.startsWith('react-native-maps/'))) {
    return {
      type: 'sourceFile',
      filePath: path.resolve(__dirname, 'components/MapView.web.tsx')
    };
  }

  // Also redirect when the request originates from within react-native-maps package
  if (platform === 'web' && context.originModulePath && context.originModulePath.includes('node_modules/react-native-maps/')) {
    return {
      type: 'sourceFile',
      filePath: path.resolve(__dirname, 'components/MapView.web.tsx')
    };
  }

  return context.resolveRequest(context, moduleName, platform);
};

// Add extraNodeModules to alias react-native to react-native-web for web builds
config.resolver.extraNodeModules = {
  ...config.resolver.extraNodeModules,
  'react-native': require.resolve('react-native-web'),
};

module.exports = config;