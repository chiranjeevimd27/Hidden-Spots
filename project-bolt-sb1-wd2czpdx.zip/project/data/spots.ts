export interface HiddenSpot {
  id: string;
  name: string;
  description: string;
  story: string;
  latitude: number;
  longitude: number;
  category: 'romantic' | 'serene' | 'creative' | 'adventure';
  photos: string[];
  ratings: {
    uniqueness: number;
    vibe: number;
    safety: number;
    crowdLevel: number;
  };
  submittedBy: string;
  submittedAt: string;
  experiences: Experience[];
  tips: string[];
}

export interface Experience {
  id: string;
  text: string;
  author: string;
  isAnonymous: boolean;
  createdAt: string;
  likes: number;
}

export const hiddenSpots: HiddenSpot[] = [
  {
    id: '1',
    name: 'Sunset Point at Gwalior Fort',
    description: 'A secluded corner of the magnificent Gwalior Fort offering breathtaking sunset views over the city.',
    story: 'Found this magical spot during my evening walk around the fort. The way the golden light hits the ancient walls creates an otherworldly atmosphere. Perfect for quiet contemplation.',
    latitude: 26.2183,
    longitude: 78.1828,
    category: 'romantic',
    photos: [
      'https://images.pexels.com/photos/1603650/pexels-photo-1603650.jpeg',
      'https://images.pexels.com/photos/2166553/pexels-photo-2166553.jpeg',
      'https://images.pexels.com/photos/3573382/pexels-photo-3573382.jpeg'
    ],
    ratings: {
      uniqueness: 4.8,
      vibe: 4.9,
      safety: 4.5,
      crowdLevel: 2.1
    },
    submittedBy: 'Arjun Mehta',
    submittedAt: '2024-12-15T10:30:00Z',
    experiences: [
      {
        id: 'exp1',
        text: 'Brought my partner here for our anniversary. The sunset was absolutely magical!',
        author: 'Priya S.',
        isAnonymous: false,
        createdAt: '2024-12-20T18:00:00Z',
        likes: 12
      },
      {
        id: 'exp2',
        text: 'Best kept secret in Gwalior. The view is unmatched.',
        author: 'Anonymous',
        isAnonymous: true,
        createdAt: '2024-12-18T16:45:00Z',
        likes: 8
      }
    ],
    tips: [
      'Visit 30 minutes before sunset for the best lighting',
      'Bring a blanket to sit on the ancient stones',
      'Check fort closing times before visiting'
    ]
  },
  {
    id: '2',
    name: 'Hidden Garden Behind Jai Vilas Palace',
    description: 'A tranquil garden space tucked away behind the grand Jai Vilas Palace, perfect for peaceful moments.',
    story: 'Discovered this serene garden while exploring the palace grounds. The old gardener showed me this peaceful corner where time seems to stand still.',
    latitude: 26.2124,
    longitude: 78.1772,
    category: 'serene',
    photos: [
      'https://images.pexels.com/photos/1666021/pexels-photo-1666021.jpeg',
      'https://images.pexels.com/photos/1472443/pexels-photo-1472443.jpeg',
      'https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg'
    ],
    ratings: {
      uniqueness: 4.6,
      vibe: 4.8,
      safety: 4.7,
      crowdLevel: 1.8
    },
    submittedBy: 'Kavya Sharma',
    submittedAt: '2024-12-10T14:20:00Z',
    experiences: [
      {
        id: 'exp3',
        text: 'Perfect spot for morning meditation. The birds chirping creates a natural symphony.',
        author: 'Rajesh K.',
        isAnonymous: false,
        createdAt: '2024-12-22T08:30:00Z',
        likes: 15
      }
    ],
    tips: [
      'Early morning (7-9 AM) is the most peaceful time',
      'Bring a book for quiet reading',
      'Respect the palace grounds and maintain silence'
    ]
  },
  {
    id: '3',
    name: 'Artist Café at Phool Bagh',
    description: 'A cozy corner café frequented by local artists and writers, hidden within the bustling Phool Bagh area.',
    story: 'Stumbled upon this artistic haven while searching for a quiet place to write. The walls are covered with local artwork and the coffee is exceptional.',
    latitude: 26.2089,
    longitude: 78.1695,
    category: 'creative',
    photos: [
      'https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg',
      'https://images.pexels.com/photos/1813466/pexels-photo-1813466.jpeg',
      'https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg'
    ],
    ratings: {
      uniqueness: 4.4,
      vibe: 4.7,
      safety: 4.6,
      crowdLevel: 3.2
    },
    submittedBy: 'Neha Gupta',
    submittedAt: '2024-12-08T11:15:00Z',
    experiences: [
      {
        id: 'exp4',
        text: 'Met some amazing local artists here. Great place for creative inspiration!',
        author: 'Anonymous',
        isAnonymous: true,
        createdAt: '2024-12-19T15:20:00Z',
        likes: 10
      },
      {
        id: 'exp5',
        text: 'Their homemade pastries are incredible. Perfect workspace for freelancers.',
        author: 'Amit T.',
        isAnonymous: false,
        createdAt: '2024-12-17T12:00:00Z',
        likes: 7
      }
    ],
    tips: [
      'Try their signature cardamom coffee',
      'Afternoon hours (2-5 PM) are less crowded',
      'Bring your laptop - they have good WiFi'
    ]
  },
  {
    id: '4',
    name: 'Secret Rock Climbing Spot near Gopachal Parvat',
    description: 'A challenging but rewarding rock climbing location known only to local adventure enthusiasts.',
    story: 'Found this incredible climbing spot through a local adventure group. The route offers stunning views of the city and a real adrenaline rush.',
    latitude: 26.2156,
    longitude: 78.1891,
    category: 'adventure',
    photos: [
      'https://images.pexels.com/photos/2041396/pexels-photo-2041396.jpeg',
      'https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg',
      'https://images.pexels.com/photos/2387418/pexels-photo-2387418.jpeg'
    ],
    ratings: {
      uniqueness: 4.9,
      vibe: 4.5,
      safety: 3.8,
      crowdLevel: 1.5
    },
    submittedBy: 'Vikram Singh',
    submittedAt: '2024-12-05T16:45:00Z',
    experiences: [
      {
        id: 'exp6',
        text: 'Epic climbing session! Make sure to bring proper gear and go with experienced climbers.',
        author: 'Adventure Club Gwalior',
        isAnonymous: false,
        createdAt: '2024-12-21T10:15:00Z',
        likes: 18
      }
    ],
    tips: [
      'Always climb with a buddy',
      'Bring proper safety equipment',
      'Best time is early morning or late afternoon',
      'Check weather conditions before visiting'
    ]
  }
];

export const getCategoryColor = (category: string) => {
  switch (category) {
    case 'romantic':
      return '#EC4899';
    case 'serene':
      return '#10B981';
    case 'creative':
      return '#F59E0B';
    case 'adventure':
      return '#EF4444';
    default:
      return '#6B7280';
  }
};

export const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'romantic':
      return 'heart';
    case 'serene':
      return 'leaf';
    case 'creative':
      return 'palette';
    case 'adventure':
      return 'mountain';
    default:
      return 'map-pin';
  }
};